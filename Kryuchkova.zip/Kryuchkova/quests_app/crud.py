# crud.py
from sqlalchemy.orm import Session
from sqlalchemy import and_
import models, schemas

def get_quests(db: Session, skip: int = 0, limit: int = 6, filters: dict = None):
    query = db.query(models.Quest)

    if filters:
        # Поиск по тексту
        if filters.get("q"):
            q = f"%{filters['q']}%"
            query = query.filter(models.Quest.title.ilike(q))

        # Жанры
        if filters.get("genre"):
            # Если передано несколько значений через запятую
            if isinstance(filters["genre"], str):
                genres = [g.strip() for g in filters["genre"].split(",")]
            else:
                genres = filters["genre"]
            query = query.filter(models.Quest.genre.in_(genres))

        # Сложность
        if filters.get("difficulty"):
            if isinstance(filters["difficulty"], str):
                difficulties = [d.strip() for d in filters["difficulty"].split(",")]
            else:
                difficulties = filters["difficulty"]
            query = query.filter(models.Quest.difficulty.in_(difficulties))

        # Уровень страха (>= выбранного)
        if filters.get("fear_level"):
            try:
                fear_level = int(filters["fear_level"])
                query = query.filter(models.Quest.fear_level >= fear_level)
            except ValueError:
                pass

        # Количество игроков (<= выбранного)
        if filters.get("players"):
            try:
                players = int(filters["players"])
                query = query.filter(models.Quest.players <= players)
            except ValueError:
                pass

    return query.offset(skip).limit(limit).all()