# main.py
import os
import shutil
import uuid
from typing import Optional

from fastapi import (
    FastAPI, Request, Form, UploadFile, File, Depends, HTTPException
)
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware
from sqlalchemy.orm import Session

from database import engine, Base, SessionLocal
import models
import crud
from auth import hash_password, verify_password, get_db, get_current_user, require_admin
from schemas import QuestCreate
import uvicorn
from datetime import datetime, date as date_type

# --- Подготовка директорий ---
os.makedirs("static/uploads", exist_ok=True)

app = FastAPI()
app.add_middleware(SessionMiddleware, secret_key="!secret_dev_change_me!")  # секрет поменять в продакшене

# --- Статика и шаблоны ---
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

# --- Создание таблиц ---
Base.metadata.create_all(bind=engine)


# --- Создание дефолтного админа ---
def create_default_admin():
    db = SessionLocal()
    try:
        admin = db.query(models.User).filter_by(username="admin").first()
        if not admin:
            a = models.User(
                username="admin",
                email="admin@example.com",
                hashed_password=hash_password("admin"),
                is_admin=True
            )
            db.add(a)
            db.commit()
            print("✅ Created default admin (username=admin password=admin). Change password immediately.")
    finally:
        db.close()


create_default_admin()


# --- Хелперы ---
def save_upload(file: UploadFile) -> str:
    """Сохраняет файл в static/uploads и возвращает относительный путь"""
    ext = os.path.splitext(file.filename)[1]
    safe_name = f"{uuid.uuid4().hex}{ext}"
    dest = os.path.join("static", "uploads", safe_name)
    with open(dest, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    return f"uploads/{safe_name}"


# --- Маршруты ---
@app.get("/", response_class=HTMLResponse)
def index(request: Request, q: Optional[str] = None, genre: Optional[str] = None,
          difficulty: Optional[str] = None, skip: int = 0, db: Session = Depends(get_db)):
    filters = {}
    if q:
        filters["q"] = q
    if genre:
        filters["genre"] = genre
    if difficulty:
        filters["difficulty"] = difficulty
    quests = crud.get_quests(db, skip=skip, limit=6, filters=filters)
    try:
        user = get_current_user(request, db)
    except:
        user = None
    return templates.TemplateResponse("index.html", {"request": request, "quests": quests, "user": user, "skip": skip})


@app.get("/api/quests", response_class=HTMLResponse)
def api_quests(request: Request, q: Optional[str] = None, genre: Optional[str] = None,
               difficulty: Optional[str] = None, skip: int = 0, limit: int = 6, db: Session = Depends(get_db)):
    filters = {}
    if q:
        filters["q"] = q
    if genre:
        filters["genre"] = genre
    if difficulty:
        filters["difficulty"] = difficulty
    quests = crud.get_quests(db, skip=skip, limit=limit, filters=filters)
    return templates.TemplateResponse("_quest_cards.html", {"request": request, "quests": quests})


@app.get("/quest/{quest_id}", response_class=HTMLResponse)
def quest_detail(request: Request, quest_id: int, db: Session = Depends(get_db)):
    quest = crud.get_quest(db, quest_id)
    if not quest:
        raise HTTPException(status_code=404, detail="Quest not found")
    try:
        user = get_current_user(request, db)
    except:
        user = None
    return templates.TemplateResponse("quest_detail.html", {"request": request, "quest": quest, "user": user})


@app.post("/book")
def book(request: Request, quest_id: int = Form(...), date: str = Form(...), timeslot: str = Form(...),
         db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    booking = crud.create_booking(db, user_id=user.id, quest_id=quest_id, date=date, timeslot=timeslot)
    if not booking:
        return JSONResponse({"success": False, "message": "Выбранный слот уже занят"}, status_code=400)
    return JSONResponse({"success": True, "message": "Бронь успешно создана"})


# --- Auth routes ---
@app.get("/login", response_class=HTMLResponse)
def login_get(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})


@app.post("/login")
def login_post(request: Request, username: str = Form(...), password: str = Form(...), db: Session = Depends(get_db)):
    user = db.query(models.User).filter_by(username=username).first()
    if not user or not verify_password(password, user.hashed_password):
        return templates.TemplateResponse("login.html", {"request": request, "error": "Неверные учётные данные"})
    request.session["user_id"] = user.id
    return RedirectResponse("/", status_code=303)


@app.get("/register", response_class=HTMLResponse)
def register_get(request: Request):
    return templates.TemplateResponse("register.html", {"request": request})


@app.post("/register")
def register_post(request: Request, username: str = Form(...), email: str = Form(None), password: str = Form(...),
                  db: Session = Depends(get_db)):
    existing = db.query(models.User).filter_by(username=username).first()
    if existing:
        return templates.TemplateResponse("register.html", {"request": request, "error": "Пользователь уже существует"})
    u = models.User(
        username=username,
        email=email,
        hashed_password=hash_password(password),
        is_admin=False
    )
    db.add(u)
    db.commit()
    request.session["user_id"] = u.id
    return RedirectResponse("/", status_code=303)


@app.get("/logout")
def logout(request: Request):
    request.session.clear()
    return RedirectResponse("/", status_code=303)


# --- Admin routes ---
@app.get("/admin", response_class=HTMLResponse)
def admin_dashboard(request: Request, db: Session = Depends(get_db), user=Depends(require_admin)):
    quests = crud.get_quests(db, skip=0, limit=1000, filters={})
    return templates.TemplateResponse("admin_dashboard.html", {"request": request, "quests": quests, "user": user})


@app.get("/admin/add", response_class=HTMLResponse)
def add_get(request: Request, user=Depends(require_admin)):
    return templates.TemplateResponse("add_quest.html", {"request": request, "user": user})


@app.post("/admin/add")
def add_post(request: Request,
             title: str = Form(...),
             description: str = Form(""),
             genre: str = Form(""),
             difficulty: str = Form(""),
             fear_level: int = Form(0),
             players: int = Form(1),
             image: Optional[UploadFile] = File(None),
             db: Session = Depends(get_db),
             user=Depends(require_admin)):
    image_path = None
    if image and image.filename:  # Проверяем, что файл был загружен
        image_path = save_upload(image)

    quest_data = {
        "title": title,
        "description": description,
        "genre": genre,
        "difficulty": difficulty,
        "fear_level": fear_level,
        "players": players
    }

    # Создаем квест через crud
    new_quest = models.Quest(
        title=title,
        description=description,
        genre=genre,
        difficulty=difficulty,
        fear_level=fear_level,
        players=players,
        image_path=image_path
    )

    db.add(new_quest)
    db.commit()
    db.refresh(new_quest)

    return RedirectResponse("/", status_code=303)  # Возвращаем на главную страницу


@app.get("/admin/edit/{quest_id}", response_class=HTMLResponse)
def edit_get(request: Request, quest_id: int, db: Session = Depends(get_db), user=Depends(require_admin)):
    quest = crud.get_quest(db, quest_id)
    if not quest:
        raise HTTPException(404, "Квест не найден")
    return templates.TemplateResponse("edit_quest.html", {"request": request, "quest": quest, "user": user})


@app.post("/admin/edit/{quest_id}")
def edit_post(request: Request, quest_id: int,
              title: str = Form(...),
              description: str = Form(""),
              genre: str = Form(""),
              difficulty: str = Form(""),
              fear_level: int = Form(0),
              players: int = Form(1),
              image: Optional[UploadFile] = File(None),
              db: Session = Depends(get_db),
              user=Depends(require_admin)):
    quest = crud.get_quest(db, quest_id)
    if not quest:
        raise HTTPException(404, "Квест не найден")

    # Обновляем данные
    quest.title = title
    quest.description = description
    quest.genre = genre
    quest.difficulty = difficulty
    quest.fear_level = fear_level
    quest.players = players

    # Обновляем изображение если загружено новое
    if image and image.filename:
        # Удаляем старое изображение если есть
        if quest.image_path:
            old_path = os.path.join("static", quest.image_path)
            if os.path.exists(old_path):
                os.remove(old_path)
        quest.image_path = save_upload(image)

    db.commit()

    return RedirectResponse("/", status_code=303)  # Возвращаем на главную


@app.post("/admin/delete/{quest_id}")
def admin_delete(quest_id: int, db: Session = Depends(get_db), user=Depends(require_admin)):
    q = crud.get_quest(db, quest_id)
    if q and q.image_path:
        file_path = os.path.join("static", q.image_path)
        if os.path.exists(file_path):
            os.remove(file_path)
    crud.delete_quest(db, quest_id)
    return RedirectResponse("/admin", status_code=303)


if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="127.0.0.1",
        port=5000,
        reload=True
    )
